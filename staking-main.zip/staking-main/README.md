# staking #staking platform #tokenstaking
Staking platform for any token ERC20

Watch video how to edit: https://youtu.be/LoS2TuVlQKA

Join my telegram: https://t.me/automatecrypto
